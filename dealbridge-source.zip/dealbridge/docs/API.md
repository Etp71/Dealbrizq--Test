# API and workflow notes

The application is a server-rendered web app. Most writes are Next.js Server Actions in `app/actions.ts` and call authenticated Supabase RPCs; they are not a stable public REST API. Keep access through the app or authenticated Supabase policies. Do not expose the service-role key or call privileged RPCs from unauthenticated browser code.

## Implemented HTTP routes

| Method | Path | Request | Behavior |
|---|---|---|---|
| `POST` | `/api/documents` | `multipart/form-data`: `file`, `name`, `target_id`, `target_type` | Authenticated upload flow for authorized listing/introduction documents. Validates PDF/JPEG/PNG file signature and size (up to 5 MiB), stores in private `vault`, and registers metadata through server-side database functions. |
| `GET` | `/api/documents/{id}` | Document UUID in route | Server-side document retrieval path; must authorize the authenticated requester against the document/target before access. Not independently integration-tested in this environment. |
| `GET` | `/auth/callback` | Supabase Auth callback query | Completes the provider callback and returns to an allowed local path. |
| `GET` | `/auth/confirm` | Supabase email confirmation query | Confirms email token and redirects to a safe local path. |

The route table describes the current app endpoints, not a supported external API contract. Verify exact redirects and response statuses against the deployed revision before integrating another client.

## Server Action operations

`mutate` in `app/actions.ts` accepts a form `op` and handles profile onboarding, listings, directories, introduction request/response, message/proposal, deal stage, support ticket, save listing/search, notification read, moderation/admin action, advertiser campaign submission and refund request. Each workflow is authenticated; database RPCs/RLS enforce the core data permissions. Do not call an action with an assumed payload outside the matching form schema.

## Data/workflow guarantees and caveats

- Marketplace matching uses deterministic preferences and returns reasons/score as preliminary compatibility. It is not a recommendation of investment suitability.
- Tender qualification distinguishes self-declared from reviewed evidence. It does not ingest official tender terms or guarantee eligibility.
- Documents use a private Storage bucket, file signature checks and an authorization route. Storage policies and cross-account access still require live Supabase tests.
- Campaign submission is rate-limited and audited, then pending moderation. Event tracking, billing and verified impressions/clicks are not implemented.
- Refund requests are recorded for review only. Payment verification, payment-provider webhooks, settlement, invoice generation and provider refund execution are not implemented.
- No public investor identities or financial capacity are seeded. Do not interpret missing or self-declared fields as verified.

For implementation details, see the SQL migrations and `docs/DEPLOYMENT.md`.
