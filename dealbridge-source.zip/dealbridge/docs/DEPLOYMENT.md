# Deployment guide

## 1. Create the project

1. Use Node.js 22+ and create a private GitHub repository for the `dealbridge/` directory. Do not commit `.env.local`, service-role keys, payment secrets, or real customer documents.
2. Create a Supabase project. Copy its project URL, publishable key and service-role key into a local `.env.local` from `.env.example`. Keep `SUPABASE_SERVICE_ROLE_KEY` server-side only.
3. Before using real personal or transaction data, choose a plan whose current quotas and backup features fit the workload. Provider free tiers change; check the current Supabase and Vercel terms rather than assuming a quota or unlimited capacity.

## 2. Apply database migrations

Run the SQL files in order using the Supabase SQL Editor or a controlled migration runner:

1. `supabase/migrations/001_core.sql`
2. `supabase/migrations/002_workflows.sql`

The first migration creates core tables, RLS policies, indexes, roles/permissions and the private `vault` bucket. The second migration adds audited/rate-limited campaign, support-ticket and refund-request RPCs and revokes direct authenticated inserts for those records. Confirm both complete without errors. Do not expose the service-role key in SQL sent to the browser.

After applying, verify RLS is enabled on every user-sensitive table, inspect Storage policies, and run tests with two separate accounts to check that one account cannot view another account's private listing, messages, organization data, or documents. The SQL has not been executed in this workspace, so this verification is a required deployment step.

## 3. Configure Supabase Auth and Storage

- In Supabase Auth settings, set the local Site URL to `http://localhost:3000` and allow the exact production origin after deployment. Allow the `/auth/callback` and `/auth/confirm` routes required by the app; avoid broad wildcard redirect rules in production.
- Enable email confirmation and password recovery. Configure approved email templates and sender/domain according to Supabase's current requirements.
- The migration creates a private `vault` bucket with a 5 MiB limit and PDF/JPEG/PNG MIME allowlist. Confirm bucket policies and authorized download flows in a test project before uploading confidential documents.
- The first Founder/Managing Director role is not assigned automatically. Register and verify the first trusted owner account, then have the Supabase project owner run the bootstrap SQL in `docs/ADMIN.md` using that account's verified email.

## 4. Local checks

```sh
cp .env.example .env.local
# Fill the four required values
npm install
npm test
npm run typecheck
npm run lint
npm run build
npm run dev
```

The included automated tests exercise pure domain helpers only. The environment used to prepare this export did not include npm, PostgreSQL, Supabase CLI, Vercel CLI, or provider credentials, so those commands and live integration tests were not run here.

## 5. Deploy to Vercel

1. Push the repository to GitHub.
2. In Vercel, import that repository and set the project Root Directory to `dealbridge/` (or move the directory contents to repository root).
3. Add the four required environment variables from `.env.example` separately for Preview and Production. Never add a service-role key to any `NEXT_PUBLIC_*` variable.
4. Deploy a Preview first. Test registration, email verification/recovery, profile setup, publishing/moderating a listing, cross-account access, document upload/download, messaging, rate limits and admin access with separate test accounts.
5. Set Supabase Site URL and redirect allowlist to the final HTTPS domain; set `NEXT_PUBLIC_SITE_URL` to that canonical origin. Test password recovery and email confirmation again.
6. Before public launch, enable monitoring and backups appropriate to the selected plan, review security headers and storage limits, and document rollback. Do not treat a successful Vercel build as evidence that database authorization is secure.

## 6. Optional integrations and costs

Razorpay, third-party transactional email, analytics and AI matching are not currently wired. Core development works without their credentials. Add each through server-side adapters and test-mode credentials before enabling it; a browser redirect must never be treated as proof of payment. Investment, lending, referral or transaction fees require local legal/regulatory review. Check current vendor pricing and free-tier limits at deployment time; no price or capacity is promised here.
