# Administrator manual

## Role and permission model

Administrative roles are stored separately from ordinary marketplace account types. The migration seeds these roles: Founder / Managing Director (`founder_md`), Marketing Director, IT Director, Listing Verification Manager, Compliance Officer, Finance Manager, Customer Support Manager, Advertising Manager, Content Editor, Deal Analyst, Moderator and Read-only Auditor. `admin_action` checks the role-permission mapping on the server and writes administrative audit events; do not rely on hiding UI controls as authorization.

The seeded permission map is intentionally scoped:

| Role | Seeded capabilities |
|---|---|
| Founder / Managing Director | All seeded permissions |
| Marketing Director | Campaign moderation, content management, operations summary |
| IT Director | Operations summary, audit read |
| Listing Verification Manager | Listing moderation |
| Compliance Officer | Listing moderation |
| Finance Manager | Financial read, refund review, audit read |
| Customer Support Manager | Support management |
| Advertising Manager | Campaign moderation |
| Content Editor | Content management |
| Deal Analyst | No broad administrative permission is implied by the seed; grant only reviewed permissions if required |
| Moderator | Listing moderation |
| Read-only Auditor | Audit read, operations summary |

Admin access does not grant general access to private deal documents. IT/Marketing roles do not receive finance/refund permissions by default. Review every permission change with least privilege.

## Bootstrap the first owner

No administrative user is created automatically. First, register an owner account through the app and verify the email. Then, as the trusted Supabase project owner, confirm the address and run the following in the Supabase SQL Editor, replacing the email with the exact verified owner address:

```sql
INSERT INTO public.user_roles (user_id, role_id)
SELECT p.id, 'founder_md'
FROM public.profiles AS p
JOIN auth.users AS u ON u.id = p.id
WHERE lower(u.email) = lower('owner@example.com')
  AND u.email_confirmed_at IS NOT NULL
ON CONFLICT (user_id, role_id) DO NOTHING;
```

Run this only in your own project as a trusted database administrator. Check the result and sign in as that owner. After bootstrap, use the audited role-assignment workflow; do not grant `founder_md` to ordinary user accounts.

## Moderation and operations

1. Review pending listings before publishing. Check provenance and remove unsupported identity, financial or credential claims.
2. Review advertiser campaign creatives and destinations. Approval does not imply a paid placement, verified impression, or revenue; those integrations are not complete.
3. Use support and refund queues only for manual review. `request_refund` records a request and moves a captured payment to `refund_requested`; no provider refund is executed in this MVP.
4. Review the audit log after sensitive admin changes. The product is intended to retain audit history; verify database privileges and backup/retention behavior before production.
5. Investigate reported abuse, handle access revocation, and follow a documented escalation process. Incident tracking and monitoring integrations are not fully wired.
6. Configure platform branding and plans through authorized actions. Recheck public pages after changes; do not add unsupported legal or investment claims.

## Security checklist

- Keep `SUPABASE_SERVICE_ROLE_KEY` in Vercel server-side environment only; rotate it if exposed.
- Use separate administrator accounts and MFA at the identity-provider/account layer where available; app-level MFA is not implemented here.
- Review role grants, RLS policies and Storage policies after every migration.
- Test owner/non-owner reads and writes with at least two accounts.
- Do not use real sensitive transaction documents until download permissions, logging, retention, backup and incident response have been independently tested.
- Do not represent self-declared profile fields or preliminary matching/tender output as independently verified.
