# DealBridge — portable business marketplace

DealBridge is an original, exportable business-marketplace codebase using Next.js, React, TypeScript, Tailwind CSS, Supabase PostgreSQL/Auth/Storage, and server-side actions. It is not affiliated with SMERGERS and contains no SMERGERS branding or copied assets.

## Readiness

This is an MVP foundation, **not a production-certified service**. Public marketplace routes, authenticated profile/listing workflows, directory/search pages, matching helpers, introduction and messaging/proposal/deal actions, private document routes, admin actions, and the initial schema/RLS policies are present. The code has not been deployed to Supabase or Vercel in this workspace. The SQL migrations and live authorization paths still require execution and environment-backed tests.

Read [Deployment](docs/DEPLOYMENT.md), [Admin Manual](docs/ADMIN.md), [API Notes](docs/API.md), and the legal drafting notes in [CONTRACT.md](docs/CONTRACT.md) before launch.

## Local setup

Requirements: Node.js 22 or newer and npm. Create a Supabase project and apply `supabase/migrations/001_core.sql` then `supabase/migrations/002_workflows.sql`. Copy `.env.example` to `.env.local`, fill the required Supabase variables, then run:

```sh
npm install
npm run dev
```

Open `http://localhost:3000`. Run the automated helper tests with `npm test`; run `npm run typecheck`, `npm run lint`, and `npm run build` before deployment. Tests using live Supabase require a separate test project and are not included in the local helper suite.

## Environment variables

- `NEXT_PUBLIC_SUPABASE_URL`: project URL.
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`: publishable client key used with the authenticated server session.
- `SUPABASE_SERVICE_ROLE_KEY`: server-only elevated key used by protected document flows. Never prefix this with `NEXT_PUBLIC_`, commit it, or expose it to browser code.
- `NEXT_PUBLIC_SITE_URL`: canonical base URL used for branding/site links.

Razorpay and third-party transactional email variables are commented out because those integrations are not implemented. The application must not imply a payment/refund was executed or a message delivered by a provider.

## What is included

- Data-driven public catalogue pages for businesses for sale, buyers, investors, fundraising, JVs, M&A, financing, franchises, brokers, advisors, professional services, infrastructure and tender partner opportunities.
- Supabase Auth registration/sign-in/recovery routes and server-rendered session handling.
- Profile, listings, directories, saved opportunities/searches, notifications, introductions, messages, proposals and deal-stage operations through server actions/RPCs.
- Deterministic matching with explainable preliminary reasons and tender qualification labels that distinguish self-declared from independently reviewed evidence.
- Private document upload/download routes with a 5 MiB size cap and PDF/JPEG/PNG signature checks.
- Seeded permission roles and explicit admin actions for moderation, public branding/plans/content, campaigns, support and refund review.
- Sponsored campaign submission/review scaffolding; creating a campaign is not a payment or proof of an impression.

## Important known limits

- Do not represent this as completed full-scope acceptance. There is no verified Supabase deployment or cross-account/RLS penetration test in this environment.
- There is no live Razorpay checkout/webhook, signed-payment verification, renewal/cancellation lifecycle, provider refund execution, invoice generation, or completed payment history. Refund requests are requests for manual review only.
- Campaign submission and moderation exist, but impression/click deduplication, bot filtering, billing and verified ad-revenue reporting do not.
- Email uses Supabase Auth configuration; no separate transactional email integration is wired. MFA, AI matching, public tender feeds, and automated tender eligibility are not implemented.
- Match and tender outputs are preliminary, not investment, legal, financing, or tender-eligibility advice. No investor identity/capacity or tender condition is fabricated.
- Legal policy pages and `docs/CONTRACT.md` are drafts; obtain jurisdiction-specific legal, securities, lending, privacy, advertising and tender-compliance review before use.
- Free plans have changing quotas and finite storage/bandwidth. The app makes no unlimited-capacity promise. Configure backups, retention, logging and abuse controls before launch.
