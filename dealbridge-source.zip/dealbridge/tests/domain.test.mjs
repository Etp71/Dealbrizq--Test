import assert from 'node:assert/strict';
import test from 'node:test';
import {accountRoles, catalogue, directoryKinds, isAllowedFile, matchListing, money, qualification, safeReturn, validMoney} from '../lib/domain.mjs';

test('marketplace roles and catalog include the supported core opportunity types', () => {
  assert.ok(accountRoles.includes('Advertiser'));
  assert.ok(catalogue['businesses-for-sale']);
  assert.ok(catalogue.infrastructure);
  assert.ok(catalogue.tenders);
  assert.deepEqual(directoryKinds, ['buyer', 'investor', 'lender', 'broker', 'advisor', 'service']);
});

test('safeReturn accepts only local relative paths', () => {
  assert.equal(safeReturn('/dashboard?tab=deals'), '/dashboard?tab=deals');
  assert.equal(safeReturn('//evil.example'), '/dashboard');
  assert.equal(safeReturn('https://evil.example'), '/dashboard');
  assert.equal(safeReturn('javascript:alert(1)'), '/dashboard');
});

test('validMoney accepts finite nonnegative values within its bound', () => {
  assert.equal(validMoney(0), 0);
  assert.equal(validMoney('1200.5'), 1200.5);
  assert.equal(validMoney(-1), null);
  assert.equal(validMoney('Infinity'), null);
  assert.equal(validMoney(1e16), null);
});

test('money handles undisclosed values and formats currency values', () => {
  assert.equal(money(null), 'Not disclosed');
  assert.equal(money(''), 'Not disclosed');
  const formatted = money(1500000, 'USD');
  assert.match(formatted, /\d/);
  assert.notEqual(formatted, '1500000');
});

test('matching returns explainable preliminary full compatibility when all declared criteria pass', () => {
  const listing = {industry:'Technology',country:'US',kind:'sale',amount:250000,revenue:800000,profit:40000,years:6,currency:'USD'};
  const criteria = {industries:['Technology'],countries:['US'],kinds:['sale'],min_amount:100000,max_amount:1000000,min_revenue:500000,profitable:true,min_years:3,currency:'USD'};
  const result = matchListing(listing, criteria);
  assert.equal(result.score, 100);
  assert.equal(result.considered, 9);
  assert.equal(result.preliminary, true);
  assert.equal(result.reasons.length, 9);
});

test('explicit false preferences are not treated as failed criteria', () => {
  const result = matchListing({profit:0}, {profitable:false});
  assert.equal(result.considered, 0);
  assert.equal(result.score, 0);
});

test('matching uses no foreign exchange conversion and marks missing criteria as mismatches', () => {
  const mismatch = matchListing({currency:'EUR',amount:100}, {currency:'USD'});
  assert.equal(mismatch.score, 0);
  assert.deepEqual(mismatch.reasons, []);
  assert.equal(mismatch.preliminary, true);
  const missing = matchListing({}, {min_amount:1});
  assert.equal(missing.score, 0);
});

test('qualification requires authorization and evidence before assessing a criterion', () => {
  const rows = qualification([{key:'turnover',label:'Annual turnover',operator:'gte',value:100}], {turnover:{value:200,evidence:'doc-1'}}, false, ['turnover']);
  assert.equal(rows[0].status, 'Additional evidence required');
  assert.equal(rows[0].source, 'Independently verified');
});

test('qualification distinguishes declared evidence from reviewed evidence', () => {
  const requirements = [
    {key:'turnover',label:'Annual turnover',operator:'gte',value:100},
    {key:'sectors',label:'Relevant sector',operator:'includes',value:'energy'}
  ];
  const declared = {turnover:{value:200,evidence:'doc-1'},sectors:{value:['energy'],evidence:'doc-2'}};
  const rows = qualification(requirements, declared, true, ['turnover']);
  assert.equal(rows[0].status, 'Potentially meets requirement');
  assert.equal(rows[0].source, 'Independently verified');
  assert.equal(rows[1].status, 'Potentially meets requirement');
  assert.equal(rows[1].source, 'Self-declared');
});

test('qualification reports unmet numeric requirements and expert-review fallback', () => {
  const rows = qualification([
    {key:'turnover',label:'Turnover',operator:'gte',value:100},
    {key:'other',label:'Special condition',operator:'custom',value:'x'}
  ], {turnover:{value:50,evidence:'doc-1'},other:{value:'x',evidence:'doc-2'}}, true, []);
  assert.equal(rows[0].status, 'Appears not to meet requirement');
  assert.equal(rows[1].status, 'Requires expert review');
});

test('file validation checks signatures, mime, and size for allowed PDF, PNG, and JPEG', () => {
  const pdf = Buffer.from('%PDF-1.7');
  const png = Buffer.from([137,80,78,71,13,10,26,10,0]);
  const jpeg = Buffer.from([255,216,255,224,1,2]);
  assert.equal(isAllowedFile(pdf, 'application/pdf', pdf.length), true);
  assert.equal(isAllowedFile(png, 'image/png', png.length), true);
  assert.equal(isAllowedFile(jpeg, 'image/jpeg', jpeg.length), true);
  assert.equal(isAllowedFile(pdf, 'image/png', pdf.length), false);
  assert.equal(isAllowedFile(pdf, 'application/pdf', 5 * 1024 * 1024 + 1), false);
  assert.equal(isAllowedFile(Buffer.from([]), 'application/pdf', 0), false);
});
