import type {MetadataRoute} from 'next';
import {catalogue} from '@/lib/domain.mjs';
export default function sitemap():MetadataRoute.Sitemap{const base=process.env.NEXT_PUBLIC_SITE_URL;if(!base)return [];const fixed=['','search',...Object.keys(catalogue),'advertise','membership','about','contact','help','blog','privacy','terms','advertising-policy','disclaimer'];return fixed.map(slug=>({url:`${base.replace(/\/$/,'')}/${slug}`,lastModified:new Date(),changeFrequency:slug===''?'weekly':'monthly',priority:slug===''?1:0.6}));}
