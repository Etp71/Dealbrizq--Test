import {NextResponse,type NextRequest} from 'next/server';
import {supabase} from '@/lib/supabase';
import {safeReturn} from '@/lib/domain.mjs';
export async function GET(request:NextRequest){const code=request.nextUrl.searchParams.get('code');if(code){const db=await supabase();const {error}=await db.auth.exchangeCodeForSession(code);if(!error){const next=safeReturn(request.nextUrl.searchParams.get('next'));return NextResponse.redirect(new URL(next,request.url));}}return NextResponse.redirect(new URL('/auth?error=Confirmation%20or%20reset%20link%20expired.%20Request%20a%20new%20one.',request.url));}
