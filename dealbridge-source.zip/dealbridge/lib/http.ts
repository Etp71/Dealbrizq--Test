import {NextResponse} from 'next/server';
export function sameOrigin(request:Request){const origin=request.headers.get('origin');return Boolean(origin&&origin===new URL(process.env.NEXT_PUBLIC_SITE_URL||request.url).origin);}
export function fail(error:string,status=400){return NextResponse.json({error},{status,headers:{'Cache-Control':'no-store'}});}
