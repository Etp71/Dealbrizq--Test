import 'server-only';
import {createServerClient} from '@supabase/ssr';
import {cookies} from 'next/headers';
export const configured = Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY);
export async function supabase() {
 if(!configured) throw new Error('Supabase is not configured. Follow README.md.');
 const store=await cookies();
 return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,{
  cookies:{getAll(){return store.getAll();},setAll(values){try{values.forEach(({name,value,options})=>store.set(name,value,options));}catch{/* Server Components cannot write cookies. proxy.ts refreshes sessions. */}}}
 });
}
export async function session(){if(!configured)return null;const db=await supabase();const {data:{user}}=await db.auth.getUser();return user;}
export async function branding(){const fallback={name:'DealBridge',navy:'#142d45',accent:'#a9743f',support_email:'',domain:process.env.NEXT_PUBLIC_SITE_URL||'http://localhost:3000',company_name:'',logo_url:''};if(!configured)return fallback;const db=await supabase();const {data}=await db.from('system_settings').select('value').eq('key','branding').eq('public',true).maybeSingle();return {...fallback,...data?.value};}
