-- DealBridge workflow hardening. Apply after 001_core.sql.
-- User-originated writes go through these audited, rate-limited SECURITY DEFINER functions.

CREATE OR REPLACE FUNCTION public.create_support_ticket(p_subject text, p_body text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  u uuid := auth.uid();
  v_id uuid;
BEGIN
  IF u IS NULL OR NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = u) THEN
    RAISE EXCEPTION 'account required' USING ERRCODE = '42501';
  END IF;
  PERFORM public.user_rate_limit('support_ticket');
  IF p_subject IS NULL OR char_length(btrim(p_subject)) NOT BETWEEN 4 AND 160
     OR p_body IS NULL OR char_length(btrim(p_body)) NOT BETWEEN 10 AND 3000 THEN
    RAISE EXCEPTION 'invalid support request' USING ERRCODE = '22023';
  END IF;
  INSERT INTO public.support_tickets(user_id, subject, body, status)
  VALUES (u, btrim(p_subject), btrim(p_body), 'open')
  RETURNING id INTO v_id;
  INSERT INTO public.audit_logs(actor_id, action, entity_type, entity_id, metadata)
  VALUES (u, 'support.ticket_created', 'support_ticket', v_id::text, '{}'::jsonb);
  RETURN v_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.create_campaign(p jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  u uuid := auth.uid();
  v_roles text[];
  v_name text;
  v_placement text;
  v_model text;
  v_budget bigint;
  v_currency text;
  v_start timestamptz;
  v_end timestamptz;
  v_url text;
  v_id uuid;
BEGIN
  IF u IS NULL OR p IS NULL OR jsonb_typeof(p) <> 'object' THEN
    RAISE EXCEPTION 'invalid campaign request' USING ERRCODE = '22023';
  END IF;
  PERFORM public.user_rate_limit('save_campaign');
  SELECT roles INTO v_roles FROM public.profiles WHERE id = u;
  IF NOT FOUND THEN RAISE EXCEPTION 'account required' USING ERRCODE = '42501'; END IF;
  IF NOT EXISTS (
    SELECT 1 FROM unnest(coalesce(v_roles, ARRAY[]::text[])) AS r(value)
    WHERE lower(r.value) = 'advertiser'
  ) THEN
    RAISE EXCEPTION 'advertiser account required' USING ERRCODE = '42501';
  END IF;

  v_name := btrim(coalesce(p->>'name', ''));
  v_placement := p->>'placement';
  v_model := p->>'pricing_model';
  v_currency := upper(coalesce(p->>'currency', ''));
  v_url := btrim(coalesce(p->>'destination_url', ''));
  IF v_name !~ '^.{2,120}$'
     OR v_placement NOT IN ('homepage_banner','sponsored_listing','search','sidebar','industry','sponsored_article','newsletter')
     OR v_model NOT IN ('CPM','CPC','FIXED')
     OR coalesce(p->>'budget','') !~ '^[0-9]{1,12}$'
     OR v_currency !~ '^[A-Z]{3}$'
     OR v_url !~ '^https://.{1,492}$' THEN
    RAISE EXCEPTION 'invalid campaign details' USING ERRCODE = '22023';
  END IF;
  v_budget := (p->>'budget')::bigint;
  BEGIN
    v_start := (p->>'start_at')::timestamptz;
    v_end := (p->>'end_at')::timestamptz;
  EXCEPTION WHEN others THEN
    RAISE EXCEPTION 'invalid campaign dates' USING ERRCODE = '22023';
  END;
  IF v_start IS NULL OR v_end IS NULL OR v_end <= v_start THEN
    RAISE EXCEPTION 'campaign end must follow its start' USING ERRCODE = '22023';
  END IF;

  INSERT INTO public.campaigns(owner_id, name, placement, pricing_model, budget, currency, start_at, end_at, destination_url, status)
  VALUES (u, v_name, v_placement, v_model, v_budget, v_currency, v_start, v_end, v_url, 'pending')
  RETURNING id INTO v_id;
  INSERT INTO public.audit_logs(actor_id, action, entity_type, entity_id, metadata)
  VALUES (u, 'campaign.submitted', 'campaign', v_id::text, jsonb_build_object('status','pending','pricing_model',v_model));
  RETURN jsonb_build_object('id',v_id,'status','pending');
END;
$$;

CREATE OR REPLACE FUNCTION public.request_refund(p_payment_id uuid, p_reason text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  u uuid := auth.uid();
  v_status text;
  v_id uuid;
  v_reason text := btrim(coalesce(p_reason, ''));
BEGIN
  IF u IS NULL THEN RAISE EXCEPTION 'authentication required' USING ERRCODE = '42501'; END IF;
  PERFORM public.user_rate_limit('refund_request');
  IF p_payment_id IS NULL OR char_length(v_reason) NOT BETWEEN 5 AND 800 THEN
    RAISE EXCEPTION 'invalid refund request' USING ERRCODE = '22023';
  END IF;
  SELECT status INTO v_status
  FROM public.payments
  WHERE id = p_payment_id AND user_id = u
  FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'payment not found' USING ERRCODE = 'P0002'; END IF;
  IF v_status <> 'captured' THEN
    RAISE EXCEPTION 'only captured payments can be reviewed for refund' USING ERRCODE = '22023';
  END IF;
  INSERT INTO public.refund_requests(user_id, payment_id, reason, status)
  VALUES (u, p_payment_id, v_reason, 'pending')
  RETURNING id INTO v_id;
  UPDATE public.payments SET status = 'refund_requested' WHERE id = p_payment_id;
  INSERT INTO public.audit_logs(actor_id, action, entity_type, entity_id, metadata)
  VALUES (u, 'refund.requested', 'refund_request', v_id::text, jsonb_build_object('payment_id',p_payment_id));
  RETURN v_id;
END;
$$;

-- Prevent authenticated users from bypassing server-side rate limits and audit entries.
REVOKE INSERT ON public.support_tickets, public.refund_requests, public.campaigns FROM authenticated;
REVOKE ALL ON FUNCTION public.create_support_ticket(text,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.create_campaign(jsonb) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.request_refund(uuid,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.create_support_ticket(text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_campaign(jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.request_refund(uuid,text) TO authenticated;
