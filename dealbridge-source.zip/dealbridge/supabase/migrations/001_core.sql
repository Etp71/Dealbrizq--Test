-- DealBridge core schema and permission layer. Fresh Supabase project only.
-- Apply as a trusted migration role. Do NOT grant the service-role key to a browser.
BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;
CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC, anon, authenticated;

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '' CHECK (char_length(full_name) <= 120),
  primary_role text NOT NULL CHECK (primary_role IN ('Business Seller','Business Buyer','Investor','Fundraising Company','Joint Venture Partner','Corporate Acquirer','Lender','Business Broker','M&A Advisor','Franchise Owner','Franchise Investor','Professional Service Provider','Advertiser')),
  roles text[] NOT NULL DEFAULT '{}', country text NOT NULL DEFAULT '' CHECK (char_length(country)<=100),
  phone text NOT NULL DEFAULT '' CHECK (char_length(phone)<=30), organization_name text NOT NULL DEFAULT '' CHECK (char_length(organization_name)<=160),
  designation text NOT NULL DEFAULT '' CHECK (char_length(designation)<=120), industry text NOT NULL DEFAULT '' CHECK (char_length(industry)<=100),
  website text NOT NULL DEFAULT '' CHECK (char_length(website)<=300), business_information text NOT NULL DEFAULT '' CHECK (char_length(business_information)<=2000),
  verified boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL CHECK(char_length(name) BETWEEN 2 AND 160),
  owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.organization_members (
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role text NOT NULL CHECK(role IN ('owner','manager','member','viewer')),
  created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(organization_id,user_id)
);
CREATE TABLE public.listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  organization_id uuid REFERENCES public.organizations(id) ON DELETE SET NULL,
  kind text NOT NULL CHECK(kind IN ('sale','fundraising','jv','acquisition','financing','franchise','infrastructure','tender')),
  title text NOT NULL CHECK(char_length(title) BETWEEN 8 AND 160), summary text NOT NULL DEFAULT '' CHECK(char_length(summary)<=1600),
  industry text NOT NULL DEFAULT '' CHECK(char_length(industry)<=100), country text NOT NULL DEFAULT '' CHECK(char_length(country)<=100), city text NOT NULL DEFAULT '' CHECK(char_length(city)<=100),
  amount numeric(20,2) CHECK(amount IS NULL OR amount>=0), currency char(3) NOT NULL CHECK(currency ~ '^[A-Z]{3}$'),
  revenue numeric(20,2) CHECK(revenue IS NULL OR revenue>=0), profit numeric(20,2) CHECK(profit IS NULL OR profit>=0), years integer CHECK(years IS NULL OR years BETWEEN 0 AND 200),
  confidential boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'pending' CHECK(status IN ('draft','pending','published','paused','archived','rejected')),
  details jsonb NOT NULL DEFAULT '{}'::jsonb CHECK(jsonb_typeof(details)='object' AND octet_length(details::text)<=16000),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX listings_search_idx ON public.listings(status,kind,industry,country,created_at DESC);
CREATE INDEX listings_amount_idx ON public.listings(amount) WHERE status='published';
CREATE INDEX listings_owner_idx ON public.listings(owner_id,status,created_at DESC);
CREATE TABLE public.listing_private (
  listing_id uuid PRIMARY KEY REFERENCES public.listings(id) ON DELETE CASCADE,
  owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  legal_name text, registration_details text, private_notes text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK(coalesce(char_length(legal_name),0)<=240 AND coalesce(char_length(registration_details),0)<=4000 AND coalesce(char_length(private_notes),0)<=4000)
);
CREATE TABLE public.directory_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK(kind IN ('buyer','investor','lender','broker','advisor','service')),
  display_name text NOT NULL CHECK(char_length(display_name) BETWEEN 2 AND 140), summary text NOT NULL DEFAULT '' CHECK(char_length(summary)<=1200),
  industry text NOT NULL DEFAULT '' CHECK(char_length(industry)<=100), country text NOT NULL DEFAULT '' CHECK(char_length(country)<=100),
  min_amount numeric(20,2) CHECK(min_amount IS NULL OR min_amount>=0), max_amount numeric(20,2) CHECK(max_amount IS NULL OR max_amount>=0),
  currency char(3) NOT NULL DEFAULT 'USD' CHECK(currency ~ '^[A-Z]{3}$'), published boolean NOT NULL DEFAULT false,
  criteria jsonb NOT NULL DEFAULT '{}'::jsonb CHECK(jsonb_typeof(criteria)='object' AND octet_length(criteria::text)<=4000),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(owner_id,kind),
  CHECK(min_amount IS NULL OR max_amount IS NULL OR min_amount<=max_amount)
);
CREATE INDEX directory_search_idx ON public.directory_profiles(kind,published,industry,country);
CREATE TABLE public.investment_mandates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL UNIQUE REFERENCES public.profiles(id) ON DELETE CASCADE,
  criteria jsonb NOT NULL DEFAULT '{}'::jsonb CHECK(jsonb_typeof(criteria)='object' AND octet_length(criteria::text)<=12000),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.saved_listings (
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(user_id,listing_id)
);
CREATE TABLE public.saved_searches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name text NOT NULL CHECK(char_length(name) BETWEEN 2 AND 100), criteria jsonb NOT NULL CHECK(jsonb_typeof(criteria)='object' AND octet_length(criteria::text)<=4000),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.introductions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  requester_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT, recipient_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','declined')),
  note text NOT NULL DEFAULT '' CHECK(char_length(note)<=800), nda_status text NOT NULL DEFAULT 'not_started' CHECK(nda_status IN ('not_started','requested','received','executed','declined')),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(listing_id,requester_id), CHECK(requester_id<>recipient_id)
);
CREATE INDEX introductions_participant_idx ON public.introductions(requester_id,recipient_id,status,created_at DESC);
CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), introduction_id uuid NOT NULL REFERENCES public.introductions(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT, body text NOT NULL CHECK(char_length(body) BETWEEN 2 AND 4000), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX messages_conversation_idx ON public.messages(introduction_id,created_at);
CREATE TABLE public.proposals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), introduction_id uuid NOT NULL REFERENCES public.introductions(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT, body text NOT NULL CHECK(char_length(body) BETWEEN 2 AND 8000),
  status text NOT NULL DEFAULT 'open' CHECK(status IN ('open','accepted','declined','withdrawn')), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), introduction_id uuid NOT NULL UNIQUE REFERENCES public.introductions(id) ON DELETE CASCADE,
  owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT, stage text NOT NULL DEFAULT 'Introduction',
  completion_requested_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  listing_id uuid REFERENCES public.listings(id) ON DELETE CASCADE, introduction_id uuid REFERENCES public.introductions(id) ON DELETE CASCADE,
  name text NOT NULL CHECK(char_length(name) BETWEEN 1 AND 120), storage_path text NOT NULL UNIQUE,
  mime text NOT NULL CHECK(mime IN ('application/pdf','image/jpeg','image/png')), size bigint NOT NULL CHECK(size BETWEEN 1 AND 5242880),
  status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','ready','revoked')),
  created_at timestamptz NOT NULL DEFAULT now(), CHECK((listing_id IS NULL) <> (introduction_id IS NULL)),
  CHECK(storage_path LIKE owner_id::text || '/%')
);
CREATE TABLE public.document_grants (
  document_id uuid NOT NULL REFERENCES public.documents(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  expires_at timestamptz, revoked_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(document_id,user_id)
);

CREATE TABLE public.roles(id text PRIMARY KEY,name text NOT NULL UNIQUE);
CREATE TABLE public.permissions(id text PRIMARY KEY,name text NOT NULL UNIQUE);
CREATE TABLE public.role_permissions(role_id text NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE, permission_id text NOT NULL REFERENCES public.permissions(id) ON DELETE CASCADE, PRIMARY KEY(role_id,permission_id));
CREATE TABLE public.user_roles(user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE, role_id text NOT NULL REFERENCES public.roles(id) ON DELETE RESTRICT, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(user_id,role_id));
CREATE TABLE public.rate_limits(bucket text PRIMARY KEY,window_start timestamptz NOT NULL,count integer NOT NULL CHECK(count>=0));

CREATE TABLE public.plans (
  id text PRIMARY KEY CHECK(id ~ '^[a-z0-9_-]{1,40}$'), name text NOT NULL CHECK(char_length(name)<=100),
  monthly_price bigint NOT NULL DEFAULT 0 CHECK(monthly_price>=0), annual_price bigint NOT NULL DEFAULT 0 CHECK(annual_price>=0),
  currency char(3) NOT NULL DEFAULT 'USD' CHECK(currency ~ '^[A-Z]{3}$'),
  listing_limit integer CHECK(listing_limit IS NULL OR listing_limit>=0), introduction_limit integer CHECK(introduction_limit IS NULL OR introduction_limit>=0), team_limit integer CHECK(team_limit IS NULL OR team_limit>=1),
  features jsonb NOT NULL DEFAULT '{}'::jsonb CHECK(jsonb_typeof(features)='object'), enabled boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  plan_id text NOT NULL REFERENCES public.plans(id), status text NOT NULL CHECK(status IN ('active','canceled','past_due','expired')),
  current_period_end timestamptz NOT NULL, cancel_at_period_end boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX subscriptions_user_idx ON public.subscriptions(user_id,status,current_period_end DESC);
CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  plan_id text NOT NULL REFERENCES public.plans(id), provider_order_id text UNIQUE, provider_payment_id text UNIQUE,
  amount bigint NOT NULL CHECK(amount>=0), currency char(3) NOT NULL CHECK(currency ~ '^[A-Z]{3}$'),
  status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','captured','failed','refund_requested','refunded')),
  billing_interval text CHECK(billing_interval IN ('month','year')), provider text NOT NULL DEFAULT 'razorpay', created_at timestamptz NOT NULL DEFAULT now(), captured_at timestamptz
);
CREATE TABLE public.invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), payment_id uuid NOT NULL UNIQUE REFERENCES public.payments(id) ON DELETE RESTRICT,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT, number text NOT NULL UNIQUE,
  total bigint NOT NULL CHECK(total>=0), currency char(3) NOT NULL CHECK(currency ~ '^[A-Z]{3}$'), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.refund_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  payment_id uuid NOT NULL REFERENCES public.payments(id) ON DELETE RESTRICT, reason text NOT NULL CHECK(char_length(reason) BETWEEN 5 AND 800),
  status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved_pending_provider','rejected','refunded')),
  reviewed_by uuid REFERENCES public.profiles(id), reviewed_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.billing_events(provider_event_id text PRIMARY KEY, payload_hash text NOT NULL CHECK(payload_hash ~ '^[a-f0-9]{64}$'), created_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX payments_user_idx ON public.payments(user_id,created_at DESC);

CREATE TABLE public.campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  name text NOT NULL CHECK(char_length(name) BETWEEN 2 AND 120), placement text NOT NULL CHECK(placement IN ('homepage_banner','sponsored_listing','search','sidebar','industry','sponsored_article','newsletter')),
  pricing_model text NOT NULL CHECK(pricing_model IN ('CPM','CPC','FIXED')), budget bigint NOT NULL CHECK(budget>=0),
  currency char(3) NOT NULL CHECK(currency ~ '^[A-Z]{3}$'), start_at timestamptz NOT NULL, end_at timestamptz NOT NULL CHECK(end_at>start_at),
  status text NOT NULL DEFAULT 'pending' CHECK(status IN ('draft','pending','approved','paused','rejected','ended')),
  destination_url text NOT NULL CHECK(destination_url ~ '^https://'), creative_document_id uuid REFERENCES public.documents(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(), CHECK(end_at<=start_at+interval '366 days')
);
CREATE INDEX campaigns_live_idx ON public.campaigns(status,placement,start_at,end_at);
CREATE TABLE public.advertisements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), campaign_id uuid NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  title text NOT NULL CHECK(char_length(title) BETWEEN 2 AND 120), body text NOT NULL DEFAULT '' CHECK(char_length(body)<=800),
  created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(campaign_id)
);
CREATE TABLE public.ad_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), campaign_id uuid NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  event_type text NOT NULL CHECK(event_type IN ('impression','click')), event_key text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ad_events_campaign_idx ON public.ad_events(campaign_id,event_type,created_at DESC);
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL CHECK(char_length(title)<=160), body text NOT NULL DEFAULT '' CHECK(char_length(body)<=800),
  read_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  subject text NOT NULL CHECK(char_length(subject) BETWEEN 4 AND 160), body text NOT NULL CHECK(char_length(body) BETWEEN 10 AND 3000),
  status text NOT NULL DEFAULT 'open' CHECK(status IN ('open','in_progress','resolved','closed')), created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), slug text NOT NULL UNIQUE CHECK(slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  title text NOT NULL CHECK(char_length(title) BETWEEN 3 AND 160), body text NOT NULL CHECK(char_length(body) BETWEEN 2 AND 20000),
  published boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), actor_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  action text NOT NULL, entity_type text NOT NULL, entity_id text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb CHECK(jsonb_typeof(metadata)='object' AND octet_length(metadata::text)<=4000),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_recent_idx ON public.audit_logs(created_at DESC);
CREATE TABLE public.consent_records(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  policy_version text NOT NULL, accepted_at timestamptz NOT NULL DEFAULT now(), UNIQUE(user_id,policy_version)
);
CREATE TABLE public.system_settings(key text PRIMARY KEY, value jsonb NOT NULL DEFAULT '{}'::jsonb, public boolean NOT NULL DEFAULT false, updated_at timestamptz NOT NULL DEFAULT now());

INSERT INTO public.roles(id,name) VALUES
('founder_md','Founder / Managing Director'),('marketing_director','Marketing Director'),('it_director','IT Director'),
('listing_verification_manager','Listing Verification Manager'),('compliance_officer','Compliance Officer'),('finance_manager','Finance Manager'),
('customer_support_manager','Customer Support Manager'),('advertising_manager','Advertising Manager'),('content_editor','Content Editor'),
('deal_analyst','Deal Analyst'),('moderator','Moderator'),('read_only_auditor','Read-only Auditor');
INSERT INTO public.permissions(id,name) VALUES
('listings.moderate','Moderate listings'),('settings.manage','Manage public settings'),('roles.manage','Manage roles'),('finance.read','Read financial records'),('finance.refund','Review refund requests'),
('plans.manage','Manage plans'),('campaigns.moderate','Review campaigns'),('content.manage','Manage public content'),('support.manage','Manage support tickets'),('audit.read','Read audit history'),('ops.read','Read operations summary');
INSERT INTO public.role_permissions(role_id,permission_id) SELECT 'founder_md',id FROM public.permissions;
INSERT INTO public.role_permissions(role_id,permission_id) VALUES
('marketing_director','campaigns.moderate'),('marketing_director','content.manage'),('marketing_director','ops.read'),
('it_director','ops.read'),('it_director','audit.read'),
('listing_verification_manager','listings.moderate'),('compliance_officer','listings.moderate'),
('finance_manager','finance.read'),('finance_manager','finance.refund'),('finance_manager','audit.read'),
('customer_support_manager','support.manage'),('advertising_manager','campaigns.moderate'),
('content_editor','content.manage'),('moderator','listings.moderate'),
('read_only_auditor','audit.read'),('read_only_auditor','ops.read');
INSERT INTO public.plans(id,name,monthly_price,annual_price,currency,listing_limit,introduction_limit,team_limit,features,enabled) VALUES
('free','Free',0,0,'USD',3,5,1,'{"search":true,"basic_matching":true}'::jsonb,true),
('business-starter','Business Starter',0,0,'USD',10,20,3,'{"premium_visibility":false}'::jsonb,false),
('business-professional','Business Professional',0,0,'USD',50,100,10,'{}'::jsonb,false),
('investor-professional','Investor Professional',0,0,'USD',10,100,5,'{}'::jsonb,false),
('advisor-professional','Advisor Professional',0,0,'USD',10,50,5,'{}'::jsonb,false),
('enterprise','Enterprise',0,0,'USD',1000,1000,100,'{}'::jsonb,false);
INSERT INTO public.system_settings(key,value,public) VALUES
('branding','{"name":"DealBridge","navy":"#142d45","accent":"#a9743f","company_name":"","support_email":"","domain":"","logo_url":""}'::jsonb,true),
('deal_stages','["Introduction","NDA","Preliminary Proposal","Due Diligence","Negotiation","Completion Requested","Completed","Paused"]'::jsonb,false);

CREATE OR REPLACE FUNCTION public.has_permission(p_permission text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public,pg_temp AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles ur JOIN public.role_permissions rp ON rp.role_id=ur.role_id WHERE ur.user_id=auth.uid() AND rp.permission_id=p_permission)
$$;
CREATE OR REPLACE FUNCTION public.is_org_member(p_org_id uuid,p_write boolean DEFAULT false)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public,pg_temp AS $$
 SELECT EXISTS(SELECT 1 FROM public.organizations o WHERE o.id=p_org_id AND o.owner_id=auth.uid()) OR EXISTS(
  SELECT 1 FROM public.organization_members m WHERE m.organization_id=p_org_id AND m.user_id=auth.uid() AND (NOT p_write OR m.role IN ('owner','manager')))
$$;
CREATE OR REPLACE FUNCTION public.accepted_participant(p_introduction_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public,pg_temp AS $$
 SELECT EXISTS(SELECT 1 FROM public.introductions i WHERE i.id=p_introduction_id AND i.status='accepted' AND auth.uid() IN (i.requester_id,i.recipient_id))
$$;
CREATE OR REPLACE FUNCTION public.can_read_document(p_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public,pg_temp AS $$
 SELECT EXISTS(SELECT 1 FROM public.documents d WHERE d.id=p_id AND d.status='ready' AND (
   d.owner_id=auth.uid() OR EXISTS(SELECT 1 FROM public.document_grants g JOIN public.introductions i ON i.id=d.introduction_id
      WHERE g.document_id=d.id AND g.user_id=auth.uid() AND g.revoked_at IS NULL AND (g.expires_at IS NULL OR g.expires_at>now())
        AND i.status='accepted' AND auth.uid() IN (i.requester_id,i.recipient_id))))
$$;
REVOKE ALL ON FUNCTION public.has_permission(text),public.is_org_member(uuid,boolean),public.accepted_participant(uuid),public.can_read_document(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.has_permission(text),public.is_org_member(uuid,boolean),public.accepted_participant(uuid),public.can_read_document(uuid) TO anon,authenticated;

CREATE OR REPLACE FUNCTION public.user_rate_limit(p_scope text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE v_limit integer; v_window interval; v_count integer; v_bucket text; v_start timestamptz;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'authentication required' USING ERRCODE='42501'; END IF;
 IF NOT EXISTS(SELECT 1 FROM auth.users u WHERE u.id=auth.uid() AND u.email_confirmed_at IS NOT NULL) THEN RAISE EXCEPTION 'verified email required' USING ERRCODE='42501'; END IF;
 CASE p_scope
 WHEN 'onboard_profile' THEN v_limit:=4;v_window:=interval '1 hour';
 WHEN 'save_listing' THEN v_limit:=12;v_window:=interval '1 hour';
 WHEN 'listing-transition' THEN v_limit:=30;v_window:=interval '1 hour';
 WHEN 'save_directory' THEN v_limit:=8;v_window:=interval '1 hour';
 WHEN 'request_introduction' THEN v_limit:=15;v_window:=interval '1 hour';
 WHEN 'respond_introduction' THEN v_limit:=30;v_window:=interval '1 hour';
 WHEN 'send_message' THEN v_limit:=40;v_window:=interval '1 hour';
 WHEN 'send_proposal' THEN v_limit:=12;v_window:=interval '1 hour';
 WHEN 'set_deal_stage' THEN v_limit:=30;v_window:=interval '1 hour';
 WHEN 'save_campaign' THEN v_limit:=6;v_window:=interval '1 day';
 WHEN 'refund_request' THEN v_limit:=3;v_window:=interval '1 day';
 WHEN 'support_ticket' THEN v_limit:=5;v_window:=interval '1 day';
 ELSE RAISE EXCEPTION 'rate limit scope unavailable' USING ERRCODE='22023';
 END CASE;
 v_bucket:=auth.uid()::text||':'||p_scope;v_start:=date_trunc('minute',now());
 INSERT INTO public.rate_limits(bucket,window_start,count) VALUES(v_bucket,v_start,1)
 ON CONFLICT(bucket) DO UPDATE SET count=CASE WHEN rate_limits.window_start<=excluded.window_start-v_window THEN 1 ELSE rate_limits.count+1 END,
 window_start=CASE WHEN rate_limits.window_start<=excluded.window_start-v_window THEN excluded.window_start ELSE rate_limits.window_start END
 RETURNING count INTO v_count;
 IF v_count>v_limit THEN RAISE EXCEPTION 'rate limit exceeded' USING ERRCODE='54000'; END IF;
END $$;
REVOKE ALL ON FUNCTION public.user_rate_limit(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.user_rate_limit(text) TO authenticated;

CREATE OR REPLACE FUNCTION public.onboard_profile(p jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,auth,pg_temp AS $$
DECLARE u uuid:=auth.uid(); v_name text; v_org text; v_primary text; v_confirmed boolean;
BEGIN
 IF u IS NULL THEN RAISE EXCEPTION 'authentication required' USING ERRCODE='42501'; END IF;
 SELECT email_confirmed_at IS NOT NULL INTO v_confirmed FROM auth.users WHERE id=u;
 IF NOT coalesce(v_confirmed,false) THEN RAISE EXCEPTION 'verify your email before onboarding' USING ERRCODE='42501'; END IF;
 IF coalesce((p->>'terms_accepted')::boolean,false) IS NOT TRUE OR coalesce((p->>'privacy_accepted')::boolean,false) IS NOT TRUE THEN RAISE EXCEPTION 'both terms and privacy consent are required' USING ERRCODE='22023'; END IF;
 v_primary:=p->>'primary_role'; IF v_primary NOT IN ('Business Seller','Business Buyer','Investor','Fundraising Company','Joint Venture Partner','Corporate Acquirer','Lender','Business Broker','M&A Advisor','Franchise Owner','Franchise Investor','Professional Service Provider','Advertiser') THEN RAISE EXCEPTION 'invalid account type' USING ERRCODE='22023'; END IF;
 v_name:=left(trim(coalesce(p->>'full_name','')),120);v_org:=left(trim(coalesce(p->>'organization_name','')),160);
 INSERT INTO public.profiles(id,full_name,primary_role,country,phone,organization_name,designation,industry,website,business_information)
 VALUES(u,v_name,v_primary,left(trim(coalesce(p->>'country','')),100),left(trim(coalesce(p->>'phone','')),30),v_org,left(trim(coalesce(p->>'designation','')),120),left(trim(coalesce(p->>'industry','')),100),left(trim(coalesce(p->>'website','')),300),left(trim(coalesce(p->>'business_information','')),2000))
 ON CONFLICT(id) DO UPDATE SET full_name=excluded.full_name,primary_role=excluded.primary_role,country=excluded.country,phone=excluded.phone,organization_name=excluded.organization_name,designation=excluded.designation,industry=excluded.industry,website=excluded.website,business_information=excluded.business_information,updated_at=now();
 IF v_org<>'' THEN
   INSERT INTO public.organizations(name,owner_id) SELECT v_org,u WHERE NOT EXISTS(SELECT 1 FROM public.organization_members m JOIN public.organizations o ON o.id=m.organization_id WHERE m.user_id=u AND o.name=v_org);
   INSERT INTO public.organization_members(organization_id,user_id,role) SELECT id,u,'owner' FROM public.organizations WHERE owner_id=u AND name=v_org ON CONFLICT DO NOTHING;
 END IF;
 INSERT INTO public.consent_records(user_id,policy_version) VALUES(u,'terms-2026-10'),(u,'privacy-2026-10') ON CONFLICT(user_id,policy_version) DO NOTHING;
 RETURN jsonb_build_object('ok',true);
END $$;

CREATE OR REPLACE FUNCTION public.save_listing(p jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE u uuid:=auth.uid(); v_id uuid; v_org uuid; v_kind text; v_status text; v_count bigint; v_limit integer; v_sub text; v_plan text; v_currency text;
BEGIN
 IF u IS NULL OR NOT EXISTS(SELECT 1 FROM public.profiles WHERE id=u) THEN RAISE EXCEPTION 'complete account profile first' USING ERRCODE='42501'; END IF;
 v_kind:=p->>'kind';IF v_kind NOT IN ('sale','fundraising','jv','acquisition','financing','franchise','infrastructure','tender') THEN RAISE EXCEPTION 'invalid listing type' USING ERRCODE='22023'; END IF;
 v_currency:=upper(p->>'currency');IF v_currency !~ '^[A-Z]{3}$' THEN RAISE EXCEPTION 'invalid currency' USING ERRCODE='22023'; END IF;
 SELECT plan_id INTO v_plan FROM public.subscriptions WHERE user_id=u AND status='active' AND current_period_end>now() ORDER BY current_period_end DESC LIMIT 1;
 SELECT listing_limit INTO v_limit FROM public.plans WHERE id=coalesce(v_plan,'free');
 IF p ? 'id' AND nullif(p->>'id','') IS NOT NULL THEN
   v_id:=(p->>'id')::uuid; SELECT status INTO v_status FROM public.listings WHERE id=v_id AND owner_id=u FOR UPDATE;
   IF NOT FOUND THEN RAISE EXCEPTION 'listing not found or not owned' USING ERRCODE='42501'; END IF;
 ELSE
   SELECT count(*) INTO v_count FROM public.listings WHERE owner_id=u AND status IN ('draft','pending','published','paused');
   IF v_limit IS NOT NULL AND v_count>=v_limit THEN RAISE EXCEPTION 'plan listing limit reached' USING ERRCODE='54000'; END IF;
   v_id:=gen_random_uuid();
 END IF;
 IF nullif(p->>'organization_id','') IS NOT NULL THEN v_org:=(p->>'organization_id')::uuid;IF NOT public.is_org_member(v_org,true) THEN RAISE EXCEPTION 'organization editor permission required' USING ERRCODE='42501'; END IF; END IF;
 INSERT INTO public.listings(id,owner_id,organization_id,kind,title,summary,industry,country,city,amount,currency,revenue,profit,years,confidential,status,details)
 VALUES(v_id,u,v_org,v_kind,left(trim(coalesce(p->>'title','')),160),left(trim(coalesce(p->>'summary','')),1600),left(trim(coalesce(p->>'industry','')),100),left(trim(coalesce(p->>'country','')),100),left(trim(coalesce(p->>'city','')),100),nullif(p->>'amount','')::numeric,v_currency,nullif(p->>'revenue','')::numeric,nullif(p->>'profit','')::numeric,nullif(p->>'years','')::integer,coalesce((p->>'confidential')::boolean,false),'pending',
   jsonb_build_object('description',left(coalesce(p#>>'{details,description}',''),4000),'funding_purpose',left(coalesce(p#>>'{details,funding_purpose}',''),800),'partner_requirements',left(coalesce(p#>>'{details,partner_requirements}',''),800),'transaction_type',left(coalesce(p#>>'{details,transaction_type}',''),100),'sale_type',left(coalesce(p#>>'{details,sale_type}',''),100),'stage',left(coalesce(p#>>'{details,stage}',''),100),'equity_offered',left(coalesce(p#>>'{details,equity_offered}',''),100)))
 ON CONFLICT(id) DO UPDATE SET organization_id=coalesce(excluded.organization_id,public.listings.organization_id),title=excluded.title,summary=excluded.summary,industry=excluded.industry,country=excluded.country,city=excluded.city,amount=excluded.amount,currency=excluded.currency,revenue=excluded.revenue,profit=excluded.profit,years=excluded.years,confidential=excluded.confidential,details=excluded.details,status='pending',updated_at=now()
 WHERE public.listings.owner_id=u AND public.listings.kind=excluded.kind;
 IF NOT FOUND THEN RAISE EXCEPTION 'listing update not allowed' USING ERRCODE='42501'; END IF;
 IF nullif(trim(p->>'legal_name'),'') IS NOT NULL THEN
  INSERT INTO public.listing_private(listing_id,owner_id,legal_name) VALUES(v_id,u,left(trim(p->>'legal_name'),240))
  ON CONFLICT(listing_id) DO UPDATE SET legal_name=excluded.legal_name,updated_at=now() WHERE listing_private.owner_id=u;
 END IF;
 RETURN v_id;
END $$;

CREATE OR REPLACE FUNCTION public.save_directory(p jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE u uuid:=auth.uid();v_id uuid;v_kind text;v_currency text;
BEGIN
 IF u IS NULL OR NOT EXISTS(SELECT 1 FROM public.profiles WHERE id=u) THEN RAISE EXCEPTION 'complete account profile first' USING ERRCODE='42501';END IF;
 v_kind:=p->>'kind';IF v_kind NOT IN ('buyer','investor','lender','broker','advisor','service') THEN RAISE EXCEPTION 'invalid directory type' USING ERRCODE='22023';END IF;
 v_currency:=upper(coalesce(p->>'currency','USD'));IF v_currency !~ '^[A-Z]{3}$' THEN RAISE EXCEPTION 'invalid currency' USING ERRCODE='22023';END IF;
 INSERT INTO public.directory_profiles(owner_id,kind,display_name,summary,industry,country,min_amount,max_amount,currency,published,criteria)
 VALUES(u,v_kind,left(trim(coalesce(p->>'display_name','')),140),left(trim(coalesce(p->>'summary','')),1200),left(trim(coalesce(p->>'industry','')),100),left(trim(coalesce(p->>'country','')),100),nullif(p->>'min_amount','')::numeric,nullif(p->>'max_amount','')::numeric,v_currency,coalesce((p->>'published')::boolean,false),jsonb_build_object('investment_stage',left(coalesce(p#>>'{criteria,investment_stage}',''),100),'transaction_types',left(coalesce(p#>>'{criteria,transaction_types}',''),300)))
 ON CONFLICT(owner_id,kind) DO UPDATE SET display_name=excluded.display_name,summary=excluded.summary,industry=excluded.industry,country=excluded.country,min_amount=excluded.min_amount,max_amount=excluded.max_amount,currency=excluded.currency,published=excluded.published,criteria=excluded.criteria,updated_at=now() RETURNING id INTO v_id;
 RETURN v_id;
END $$;
CREATE OR REPLACE FUNCTION public.listing_transition(p_id uuid,p_status text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
BEGIN IF p_status NOT IN ('paused','archived','pending') THEN RAISE EXCEPTION 'invalid status transition' USING ERRCODE='22023';END IF;
 UPDATE public.listings SET status=p_status,updated_at=now() WHERE id=p_id AND owner_id=auth.uid() AND status IN ('draft','pending','published','paused','rejected');
 IF NOT FOUND THEN RAISE EXCEPTION 'listing not found or transition unavailable' USING ERRCODE='42501';END IF;END $$;

CREATE OR REPLACE FUNCTION public.request_introduction(p_listing_id uuid,p_note text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE u uuid:=auth.uid();v_recipient uuid;v_limit integer;v_plan text;v_count bigint;v_id uuid;
BEGIN SELECT owner_id INTO v_recipient FROM public.listings WHERE id=p_listing_id AND status='published';
 IF NOT FOUND OR v_recipient=u THEN RAISE EXCEPTION 'published opportunity unavailable' USING ERRCODE='42501';END IF;
 SELECT plan_id INTO v_plan FROM public.subscriptions WHERE user_id=u AND status='active' AND current_period_end>now() ORDER BY current_period_end DESC LIMIT 1;
 SELECT introduction_limit INTO v_limit FROM public.plans WHERE id=coalesce(v_plan,'free');
 SELECT count(*) INTO v_count FROM public.introductions WHERE requester_id=u AND created_at>=date_trunc('month',now());
 IF v_limit IS NOT NULL AND v_count>=v_limit THEN RAISE EXCEPTION 'plan introduction limit reached' USING ERRCODE='54000';END IF;
 INSERT INTO public.introductions(listing_id,requester_id,recipient_id,note) VALUES(p_listing_id,u,v_recipient,left(trim(coalesce(p_note,'')),800)) RETURNING id INTO v_id;
 INSERT INTO public.notifications(user_id,title,body) VALUES(v_recipient,'New introduction request','A marketplace member requested an introduction to a published opportunity.');
 RETURN v_id;
END $$;
CREATE OR REPLACE FUNCTION public.respond_introduction(p_id uuid,p_accept boolean)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE v_listing uuid;v_title text;
BEGIN UPDATE public.introductions SET status=CASE WHEN p_accept THEN 'accepted' ELSE 'declined' END,updated_at=now() WHERE id=p_id AND recipient_id=auth.uid() AND status='pending' RETURNING listing_id INTO v_listing;
 IF NOT FOUND THEN RAISE EXCEPTION 'request not found or already answered' USING ERRCODE='42501';END IF;
 IF p_accept THEN SELECT title INTO v_title FROM public.listings WHERE id=v_listing;INSERT INTO public.deals(introduction_id,owner_id,stage) SELECT p_id,owner_id,'Introduction' FROM public.listings WHERE id=v_listing ON CONFLICT(introduction_id) DO NOTHING;END IF;
END $$;
CREATE OR REPLACE FUNCTION public.send_message(p_id uuid,p_body text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE v_id uuid;
BEGIN IF NOT public.accepted_participant(p_id) THEN RAISE EXCEPTION 'accepted introduction required' USING ERRCODE='42501';END IF;
 IF char_length(trim(coalesce(p_body,'')))<2 OR char_length(p_body)>4000 THEN RAISE EXCEPTION 'invalid message length' USING ERRCODE='22023';END IF;
 INSERT INTO public.messages(introduction_id,sender_id,body) VALUES(p_id,auth.uid(),trim(p_body)) RETURNING id INTO v_id;
 INSERT INTO public.notifications(user_id,title,body) SELECT CASE WHEN i.requester_id=auth.uid() THEN i.recipient_id ELSE i.requester_id END,'New deal message','A participant sent a message in an accepted introduction.' FROM public.introductions i WHERE i.id=p_id;
 RETURN v_id;END $$;
CREATE OR REPLACE FUNCTION public.send_proposal(p_id uuid,p_body text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE v_id uuid;
BEGIN IF NOT public.accepted_participant(p_id) THEN RAISE EXCEPTION 'accepted introduction required' USING ERRCODE='42501';END IF;
 IF char_length(trim(coalesce(p_body,'')))<2 OR char_length(p_body)>8000 THEN RAISE EXCEPTION 'invalid proposal length' USING ERRCODE='22023';END IF;
 INSERT INTO public.proposals(introduction_id,sender_id,body) VALUES(p_id,auth.uid(),trim(p_body)) RETURNING id INTO v_id;
 RETURN v_id;END $$;
CREATE OR REPLACE FUNCTION public.set_deal_stage(p_id uuid,p_stage text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE d public.deals%ROWTYPE;v_stages jsonb;v_other uuid;
BEGIN SELECT * INTO d FROM public.deals WHERE id=p_id FOR UPDATE;IF NOT FOUND THEN RAISE EXCEPTION 'deal not found' USING ERRCODE='42501';END IF;
 IF NOT public.accepted_participant(d.introduction_id) THEN RAISE EXCEPTION 'accepted deal participant required' USING ERRCODE='42501';END IF;
 SELECT value INTO v_stages FROM public.system_settings WHERE key='deal_stages';
 IF p_stage<>'Completed' AND NOT (v_stages ? p_stage) THEN RAISE EXCEPTION 'stage unavailable' USING ERRCODE='22023';END IF;
 IF p_stage='Completed' THEN
   IF d.completion_requested_by IS NULL THEN UPDATE public.deals SET stage='Completion Requested',completion_requested_by=auth.uid(),updated_at=now() WHERE id=p_id;
   ELSIF d.completion_requested_by<>auth.uid() THEN UPDATE public.deals SET stage='Completed',completion_requested_by=NULL,updated_at=now() WHERE id=p_id;
   ELSE RAISE EXCEPTION 'the other participant must confirm completion' USING ERRCODE='22023';END IF;
 ELSE UPDATE public.deals SET stage=p_stage,completion_requested_by=NULL,updated_at=now() WHERE id=p_id;END IF;
END $$;

CREATE OR REPLACE FUNCTION public.can_read_document(p_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public,pg_temp AS $$
 SELECT EXISTS(SELECT 1 FROM public.documents d WHERE d.id=p_id AND d.status='ready' AND (
   d.owner_id=auth.uid() OR EXISTS(SELECT 1 FROM public.document_grants g JOIN public.introductions i ON i.id=d.introduction_id
     WHERE g.document_id=d.id AND g.user_id=auth.uid() AND g.revoked_at IS NULL AND (g.expires_at IS NULL OR g.expires_at>now()) AND i.status='accepted' AND auth.uid() IN(i.requester_id,i.recipient_id))))
$$;
CREATE OR REPLACE FUNCTION public.register_document(p jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE u uuid:=auth.uid();v_listing uuid;v_intro uuid;v_path text;v_id uuid;v_recipient uuid;
BEGIN
 IF u IS NULL OR NOT EXISTS(SELECT 1 FROM public.profiles WHERE id=u) THEN RAISE EXCEPTION 'account required' USING ERRCODE='42501';END IF;
 v_path:=p->>'storage_path';IF v_path IS NULL OR v_path NOT LIKE u::text||'/%' OR char_length(v_path)>240 THEN RAISE EXCEPTION 'invalid private storage path' USING ERRCODE='22023';END IF;
 IF nullif(p->>'listing_id','') IS NOT NULL THEN v_listing:=(p->>'listing_id')::uuid;IF NOT EXISTS(SELECT 1 FROM public.listings WHERE id=v_listing AND owner_id=u) THEN RAISE EXCEPTION 'listing owner authorization required' USING ERRCODE='42501';END IF;
 ELSIF nullif(p->>'introduction_id','') IS NOT NULL THEN v_intro:=(p->>'introduction_id')::uuid;IF NOT public.accepted_participant(v_intro) THEN RAISE EXCEPTION 'accepted introduction required' USING ERRCODE='42501';END IF;
 ELSE RAISE EXCEPTION 'select an authorized listing or accepted introduction' USING ERRCODE='22023';END IF;
 INSERT INTO public.documents(owner_id,listing_id,introduction_id,name,storage_path,mime,size) VALUES(u,v_listing,v_intro,left(trim(coalesce(p->>'name','Private document')),120),v_path,p->>'mime',(p->>'size')::bigint) RETURNING id INTO v_id;
 IF v_intro IS NOT NULL AND nullif(p->>'recipient_user_id','') IS NOT NULL THEN
   v_recipient:=(p->>'recipient_user_id')::uuid;
   IF NOT EXISTS(SELECT 1 FROM public.introductions i WHERE i.id=v_intro AND i.status='accepted' AND v_recipient IN(i.requester_id,i.recipient_id) AND v_recipient<>u) THEN RAISE EXCEPTION 'document recipient is not a deal participant' USING ERRCODE='42501';END IF;
   INSERT INTO public.document_grants(document_id,user_id,expires_at) VALUES(v_id,v_recipient,coalesce(nullif(p->>'expires_at','')::timestamptz,now()+interval '30 days'));
 END IF;
 INSERT INTO public.audit_logs(actor_id,action,entity_type,entity_id,metadata) VALUES(u,'document.pending','document',v_id::text,jsonb_build_object('listing_id',v_listing,'introduction_id',v_intro));
 RETURN jsonb_build_object('id',v_id);
END $$;
CREATE OR REPLACE FUNCTION public.finalize_document(p_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE d public.documents%ROWTYPE;v_size bigint;v_mime text;
BEGIN SELECT * INTO d FROM public.documents WHERE id=p_id AND owner_id=auth.uid() AND status='pending' FOR UPDATE;IF NOT FOUND THEN RAISE EXCEPTION 'pending document not found' USING ERRCODE='42501';END IF;
 SELECT (metadata->>'size')::bigint,metadata->>'mimetype' INTO v_size,v_mime FROM storage.objects WHERE bucket_id='vault' AND name=d.storage_path;
 IF NOT FOUND OR v_size<>d.size OR v_mime<>d.mime THEN RAISE EXCEPTION 'stored document validation failed' USING ERRCODE='22023';END IF;
 UPDATE public.documents SET status='ready' WHERE id=p_id;INSERT INTO public.audit_logs(actor_id,action,entity_type,entity_id,metadata) VALUES(auth.uid(),'document.ready','document',p_id::text,jsonb_build_object('size',d.size,'mime',d.mime));
END $$;
CREATE OR REPLACE FUNCTION public.revoke_document(p_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
BEGIN UPDATE public.documents SET status='revoked' WHERE id=p_id AND owner_id=auth.uid() AND status<>'revoked';IF NOT FOUND THEN RAISE EXCEPTION 'document not found' USING ERRCODE='42501';END IF;
 UPDATE public.document_grants SET revoked_at=now() WHERE document_id=p_id AND revoked_at IS NULL;
 INSERT INTO public.audit_logs(actor_id,action,entity_type,entity_id) VALUES(auth.uid(),'document.revoked','document',p_id::text);END $$;
CREATE OR REPLACE FUNCTION public.grant_document(p_id uuid,p_user_id uuid,p_expires_at timestamptz DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE d public.documents%ROWTYPE;v_intro public.introductions%ROWTYPE;
BEGIN SELECT * INTO d FROM public.documents WHERE id=p_id AND owner_id=auth.uid() AND status='ready';IF NOT FOUND OR d.introduction_id IS NULL THEN RAISE EXCEPTION 'ready introduction document required' USING ERRCODE='42501';END IF;
 SELECT * INTO v_intro FROM public.introductions WHERE id=d.introduction_id AND status='accepted';
 IF NOT FOUND OR p_user_id NOT IN(v_intro.requester_id,v_intro.recipient_id) OR p_user_id=auth.uid() THEN RAISE EXCEPTION 'recipient must be the other accepted participant' USING ERRCODE='42501';END IF;
 INSERT INTO public.document_grants(document_id,user_id,expires_at) VALUES(p_id,p_user_id,coalesce(p_expires_at,now()+interval '30 days')) ON CONFLICT(document_id,user_id) DO UPDATE SET expires_at=excluded.expires_at,revoked_at=NULL;
 INSERT INTO public.audit_logs(actor_id,action,entity_type,entity_id,metadata) VALUES(auth.uid(),'document.grant','document',p_id::text,jsonb_build_object('recipient',p_user_id,'expires_at',coalesce(p_expires_at,now()+interval '30 days')));
END $$;

CREATE OR REPLACE FUNCTION public.admin_action(p_action text,p_id text DEFAULT NULL,p_data jsonb DEFAULT '{}'::jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE u uuid:=auth.uid();v_perm text;v_id uuid;v_role text;v_url text;
BEGIN
 v_perm:=CASE p_action WHEN 'approve_listing' THEN 'listings.moderate' WHEN 'reject_listing' THEN 'listings.moderate' WHEN 'approve_campaign' THEN 'campaigns.moderate' WHEN 'reject_campaign' THEN 'campaigns.moderate' WHEN 'save_branding' THEN 'settings.manage' WHEN 'save_plan' THEN 'plans.manage' WHEN 'assign_role' THEN 'roles.manage' WHEN 'publish_article' THEN 'content.manage' WHEN 'resolve_ticket' THEN 'support.manage' WHEN 'review_refund' THEN 'finance.refund' ELSE NULL END;
 IF v_perm IS NULL OR NOT public.has_permission(v_perm) THEN RAISE EXCEPTION 'administrative permission denied' USING ERRCODE='42501';END IF;
 IF p_action IN ('approve_listing','reject_listing') THEN
   v_id:=p_id::uuid;UPDATE public.listings SET status=CASE WHEN p_action='approve_listing' THEN 'published' ELSE 'rejected' END,updated_at=now() WHERE id=v_id AND status='pending';IF NOT FOUND THEN RAISE EXCEPTION 'pending listing not found' USING ERRCODE='22023';END IF;
 ELSIF p_action IN ('approve_campaign','reject_campaign') THEN
   v_id:=p_id::uuid;UPDATE public.campaigns SET status=CASE WHEN p_action='approve_campaign' THEN 'approved' ELSE 'rejected' END WHERE id=v_id AND status='pending';IF NOT FOUND THEN RAISE EXCEPTION 'pending campaign not found' USING ERRCODE='22023';END IF;
 ELSIF p_action='save_branding' THEN
   v_url:=coalesce(p_data->>'logo_url','');IF v_url<>'' AND v_url !~ '^https://' THEN RAISE EXCEPTION 'logo URL must use HTTPS' USING ERRCODE='22023';END IF;
   v_url:=coalesce(p_data->>'domain','');IF v_url<>'' AND v_url !~ '^https://' THEN RAISE EXCEPTION 'canonical URL must use HTTPS' USING ERRCODE='22023';END IF;
   INSERT INTO public.system_settings(key,value,public) VALUES('branding',jsonb_build_object('name',left(coalesce(p_data->>'name','DealBridge'),80),'navy',CASE WHEN coalesce(p_data->>'navy','#142d45')~'^#[0-9a-fA-F]{6}$' THEN p_data->>'navy' ELSE '#142d45' END,'accent',CASE WHEN coalesce(p_data->>'accent','#a9743f')~'^#[0-9a-fA-F]{6}$' THEN p_data->>'accent' ELSE '#a9743f' END,'support_email',left(coalesce(p_data->>'support_email',''),254),'company_name',left(coalesce(p_data->>'company_name',''),160),'domain',v_url,'logo_url',left(coalesce(p_data->>'logo_url',''),500)),true) ON CONFLICT(key) DO UPDATE SET value=excluded.value,public=true,updated_at=now();
 ELSIF p_action='save_plan' THEN
   IF NOT EXISTS(SELECT 1 FROM public.plans WHERE id=p_data->>'id') THEN RAISE EXCEPTION 'plan not found' USING ERRCODE='22023';END IF;
   UPDATE public.plans SET name=left(coalesce(p_data->>'name',name),100),monthly_price=greatest(0,coalesce((p_data->>'monthly_price')::bigint,monthly_price)),annual_price=greatest(0,coalesce((p_data->>'annual_price')::bigint,annual_price)),listing_limit=greatest(0,coalesce((p_data->>'listing_limit')::integer,listing_limit)),introduction_limit=greatest(0,coalesce((p_data->>'introduction_limit')::integer,introduction_limit)),team_limit=greatest(1,coalesce((p_data->>'team_limit')::integer,team_limit)),features=CASE WHEN jsonb_typeof(p_data->'features')='object' THEN p_data->'features' ELSE features END,enabled=(id='free') WHERE id=p_data->>'id';
 ELSIF p_action='assign_role' THEN
   v_id:=(p_data->>'user_id')::uuid;v_role:=p_data->>'role_id';IF NOT EXISTS(SELECT 1 FROM public.roles WHERE id=v_role) OR NOT EXISTS(SELECT 1 FROM public.profiles WHERE id=v_id) THEN RAISE EXCEPTION 'target user or role not found' USING ERRCODE='22023';END IF;
   INSERT INTO public.user_roles(user_id,role_id) VALUES(v_id,v_role) ON CONFLICT DO NOTHING;
 ELSIF p_action='publish_article' THEN
   INSERT INTO public.articles(slug,title,body,published) VALUES(left(coalesce(p_data->>'slug',''),100),left(coalesce(p_data->>'title',''),160),left(coalesce(p_data->>'body',''),20000),coalesce((p_data->>'published')::boolean,false))
   ON CONFLICT(slug) DO UPDATE SET title=excluded.title,body=excluded.body,published=excluded.published,updated_at=now();
 ELSIF p_action='resolve_ticket' THEN
   v_id:=p_id::uuid;UPDATE public.support_tickets SET status='resolved',updated_at=now() WHERE id=v_id AND status IN ('open','in_progress');IF NOT FOUND THEN RAISE EXCEPTION 'open support ticket not found' USING ERRCODE='22023';END IF;
 ELSIF p_action='review_refund' THEN
   v_id:=p_id::uuid;UPDATE public.refund_requests SET status=CASE WHEN p_data->>'decision'='approved' THEN 'approved_pending_provider' ELSE 'rejected' END,reviewed_by=u,reviewed_at=now() WHERE id=v_id AND status='pending';IF NOT FOUND THEN RAISE EXCEPTION 'pending refund request not found' USING ERRCODE='22023';END IF;
 END IF;
 INSERT INTO public.audit_logs(actor_id,action,entity_type,entity_id,metadata) VALUES(u,p_action,CASE WHEN p_action LIKE '%listing%' THEN 'listing' WHEN p_action LIKE '%campaign%' THEN 'campaign' WHEN p_action='assign_role' THEN 'user_role' WHEN p_action='publish_article' THEN 'article' WHEN p_action='resolve_ticket' THEN 'support_ticket' WHEN p_action='review_refund' THEN 'refund_request' ELSE 'system_setting' END,p_id,jsonb_build_object('permission',v_perm,'decision',nullif(p_data->>'decision','')));
END $$;

CREATE OR REPLACE FUNCTION public.record_ad_event(p_campaign_id uuid,p_type text,p_key text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE v_count bigint;
BEGIN
 IF auth.role()<>'service_role' THEN RAISE EXCEPTION 'service adapter required' USING ERRCODE='42501';END IF;
 IF p_type NOT IN ('impression','click') OR p_key IS NULL OR char_length(p_key)<16 OR char_length(p_key)>200 THEN RAISE EXCEPTION 'invalid event input' USING ERRCODE='22023';END IF;
 INSERT INTO public.ad_events(campaign_id,event_type,event_key) SELECT id,p_type,p_key FROM public.campaigns WHERE id=p_campaign_id AND status='approved' AND now() BETWEEN start_at AND end_at ON CONFLICT(event_key) DO NOTHING;
 GET DIAGNOSTICS v_count=ROW_COUNT;RETURN v_count=1;
END $$;

CREATE OR REPLACE FUNCTION public.consume_rate_limit(p_key text,p_limit integer,p_window integer)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE v_count integer;v_start timestamptz:=date_trunc('minute',now());
BEGIN
 IF auth.role()<>'service_role' OR p_limit<1 OR p_limit>10000 OR p_window<1 OR p_window>86400 OR p_key IS NULL OR char_length(p_key)>240 THEN RAISE EXCEPTION 'invalid service rate-limit request' USING ERRCODE='42501';END IF;
 INSERT INTO public.rate_limits(bucket,window_start,count) VALUES('service:'||p_key,v_start,1)
 ON CONFLICT(bucket) DO UPDATE SET count=CASE WHEN rate_limits.window_start<=excluded.window_start-make_interval(secs=>p_window) THEN 1 ELSE rate_limits.count+1 END,
 window_start=CASE WHEN rate_limits.window_start<=excluded.window_start-make_interval(secs=>p_window) THEN excluded.window_start ELSE rate_limits.window_start END RETURNING count INTO v_count;
 RETURN v_count<=p_limit;
END $$;

-- Least-privilege grants. No direct application writes to listings, messages, roles, documents or audit history.
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon,authenticated;
GRANT USAGE ON SCHEMA public TO anon,authenticated;
GRANT SELECT ON public.articles,public.plans TO anon,authenticated;
GRANT SELECT(id,kind,title,summary,industry,country,city,amount,currency,revenue,profit,years,confidential,status,details,created_at,updated_at) ON public.listings TO anon,authenticated;
GRANT SELECT(owner_id,organization_id) ON public.listings TO authenticated;
GRANT SELECT(id,kind,display_name,summary,industry,country,min_amount,max_amount,currency,published,criteria,created_at,updated_at) ON public.directory_profiles TO anon,authenticated;
GRANT SELECT(owner_id) ON public.directory_profiles TO authenticated;
GRANT SELECT ON public.profiles,public.organizations,public.organization_members,public.listing_private,public.investment_mandates,public.saved_listings,public.saved_searches,public.introductions,public.messages,public.proposals,public.deals,public.documents,public.document_grants,public.user_roles,public.roles,public.permissions,public.role_permissions,public.subscriptions,public.payments,public.invoices,public.refund_requests,public.campaigns,public.advertisements,public.ad_events,public.notifications,public.support_tickets,public.audit_logs,public.consent_records,public.system_settings TO authenticated;
GRANT SELECT(owner_id,organization_id) ON public.listings TO authenticated;
GRANT INSERT,DELETE ON public.saved_listings,public.saved_searches TO authenticated;
GRANT INSERT ON public.support_tickets,public.refund_requests TO authenticated;
GRANT UPDATE(read_at) ON public.notifications TO authenticated;
REVOKE ALL ON FUNCTION public.onboard_profile(jsonb),public.save_listing(jsonb),public.save_directory(jsonb),public.listing_transition(uuid,text),public.request_introduction(uuid,text),public.respond_introduction(uuid,boolean),public.send_message(uuid,text),public.send_proposal(uuid,text),public.set_deal_stage(uuid,text),public.register_document(jsonb),public.finalize_document(uuid),public.revoke_document(uuid),public.grant_document(uuid,uuid,timestamptz),public.admin_action(text,text,jsonb) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.onboard_profile(jsonb),public.save_listing(jsonb),public.save_directory(jsonb),public.listing_transition(uuid,text),public.request_introduction(uuid,text),public.respond_introduction(uuid,boolean),public.send_message(uuid,text),public.send_proposal(uuid,text),public.set_deal_stage(uuid,text),public.register_document(jsonb),public.finalize_document(uuid),public.revoke_document(uuid),public.grant_document(uuid,uuid,timestamptz),public.admin_action(text,text,jsonb) TO authenticated;
REVOKE ALL ON FUNCTION public.record_ad_event(uuid,text,text),public.consume_rate_limit(text,integer,integer) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.record_ad_event(uuid,text,text),public.consume_rate_limit(text,integer,integer) TO service_role;

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.organization_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.listing_private ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.directory_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.investment_mandates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_searches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.introductions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.proposals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.document_grants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.refund_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.billing_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.advertisements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ad_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.consent_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY profiles_read ON public.profiles FOR SELECT TO authenticated USING(id=auth.uid() OR public.has_permission('roles.manage'));
CREATE POLICY org_read ON public.organizations FOR SELECT TO authenticated USING(owner_id=auth.uid() OR public.is_org_member(id,false));
CREATE POLICY org_members_read ON public.organization_members FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.is_org_member(organization_id,false));
CREATE POLICY listing_read ON public.listings FOR SELECT USING(status='published' OR owner_id=auth.uid() OR public.is_org_member(organization_id,false) OR public.has_permission('listings.moderate') OR EXISTS(SELECT 1 FROM public.introductions i WHERE i.listing_id=id AND i.status='accepted' AND auth.uid() IN(i.requester_id,i.recipient_id)));
CREATE POLICY listing_private_read ON public.listing_private FOR SELECT TO authenticated USING(owner_id=auth.uid() OR EXISTS(SELECT 1 FROM public.introductions i WHERE i.listing_id=public.listing_private.listing_id AND i.status='accepted' AND auth.uid() IN(i.requester_id,i.recipient_id)));
CREATE POLICY directory_read ON public.directory_profiles FOR SELECT USING(published OR owner_id=auth.uid());
CREATE POLICY mandates_owner ON public.investment_mandates FOR SELECT TO authenticated USING(owner_id=auth.uid());
CREATE POLICY saved_listings_owner ON public.saved_listings FOR SELECT TO authenticated USING(user_id=auth.uid());
CREATE POLICY saved_listings_insert ON public.saved_listings FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid() AND EXISTS(SELECT 1 FROM public.listings l WHERE l.id=listing_id AND l.status='published'));
CREATE POLICY saved_listings_delete ON public.saved_listings FOR DELETE TO authenticated USING(user_id=auth.uid());
CREATE POLICY saved_searches_owner ON public.saved_searches FOR SELECT TO authenticated USING(user_id=auth.uid());
CREATE POLICY saved_searches_insert ON public.saved_searches FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid());
CREATE POLICY intro_read ON public.introductions FOR SELECT TO authenticated USING(auth.uid() IN(requester_id,recipient_id));
CREATE POLICY messages_read ON public.messages FOR SELECT TO authenticated USING(public.accepted_participant(introduction_id));
CREATE POLICY proposals_read ON public.proposals FOR SELECT TO authenticated USING(public.accepted_participant(introduction_id));
CREATE POLICY deals_read ON public.deals FOR SELECT TO authenticated USING(public.accepted_participant(introduction_id));
CREATE POLICY documents_read ON public.documents FOR SELECT TO authenticated USING(public.can_read_document(id) OR owner_id=auth.uid());
CREATE POLICY grants_read ON public.document_grants FOR SELECT TO authenticated USING(user_id=auth.uid() OR EXISTS(SELECT 1 FROM public.documents d WHERE d.id=document_id AND d.owner_id=auth.uid()));
CREATE POLICY roles_admin_read ON public.roles FOR SELECT TO authenticated USING(public.has_permission('roles.manage'));
CREATE POLICY permissions_admin_read ON public.permissions FOR SELECT TO authenticated USING(public.has_permission('roles.manage'));
CREATE POLICY role_permissions_admin_read ON public.role_permissions FOR SELECT TO authenticated USING(public.has_permission('roles.manage'));
CREATE POLICY user_roles_self_or_admin ON public.user_roles FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.has_permission('roles.manage'));
CREATE POLICY plans_visible ON public.plans FOR SELECT USING(enabled OR public.has_permission('plans.manage'));
CREATE POLICY subscriptions_self_finance ON public.subscriptions FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.has_permission('finance.read'));
CREATE POLICY payments_self_finance ON public.payments FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.has_permission('finance.read'));
CREATE POLICY invoices_self_finance ON public.invoices FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.has_permission('finance.read'));
CREATE POLICY refunds_self_finance ON public.refund_requests FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.has_permission('finance.refund'));
CREATE POLICY refund_insert_owner ON public.refund_requests FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid() AND status='pending' AND EXISTS(SELECT 1 FROM public.payments p WHERE p.id=payment_id AND p.user_id=auth.uid() AND p.status='captured'));
CREATE POLICY campaign_owner_or_admin ON public.campaigns FOR SELECT TO authenticated USING(owner_id=auth.uid() OR public.has_permission('campaigns.moderate'));
CREATE POLICY ad_owner_or_admin ON public.advertisements FOR SELECT TO authenticated USING(EXISTS(SELECT 1 FROM public.campaigns c WHERE c.id=campaign_id AND (c.owner_id=auth.uid() OR public.has_permission('campaigns.moderate'))));
CREATE POLICY events_owner_or_admin ON public.ad_events FOR SELECT TO authenticated USING(EXISTS(SELECT 1 FROM public.campaigns c WHERE c.id=campaign_id AND (c.owner_id=auth.uid() OR public.has_permission('campaigns.moderate'))));
CREATE POLICY notifications_self ON public.notifications FOR SELECT TO authenticated USING(user_id=auth.uid());
CREATE POLICY notifications_update_self ON public.notifications FOR UPDATE TO authenticated USING(user_id=auth.uid()) WITH CHECK(user_id=auth.uid());
CREATE POLICY support_self_or_manager ON public.support_tickets FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.has_permission('support.manage'));
CREATE POLICY support_insert_self ON public.support_tickets FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid() AND status='open');
CREATE POLICY articles_public_or_editor ON public.articles FOR SELECT USING(published OR public.has_permission('content.manage'));
CREATE POLICY audit_read ON public.audit_logs FOR SELECT TO authenticated USING(public.has_permission('audit.read'));
CREATE POLICY consent_self_or_admin ON public.consent_records FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.has_permission('roles.manage'));
CREATE POLICY settings_public_or_admin ON public.system_settings FOR SELECT USING((public AND key='branding') OR public.has_permission('settings.manage') OR public.has_permission('ops.read'));

CREATE VIEW public.public_advertisements WITH (security_invoker=false) AS
 SELECT a.id,a.title,a.body,c.placement,c.destination_url
 FROM public.advertisements a JOIN public.campaigns c ON c.id=a.campaign_id
 WHERE c.status='approved' AND c.start_at<=now() AND c.end_at>now();
GRANT SELECT ON public.public_advertisements TO anon,authenticated;

INSERT INTO storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
VALUES('vault','vault',false,5242880,ARRAY['application/pdf','image/jpeg','image/png'])
ON CONFLICT(id) DO UPDATE SET public=false,file_size_limit=5242880,allowed_mime_types=ARRAY['application/pdf','image/jpeg','image/png'];
-- Deliberately no authenticated storage.objects policies. Uploads and downloads use the server proxy,
-- and the server re-checks RLS-bound document authorization before streaming bytes.

COMMIT;
